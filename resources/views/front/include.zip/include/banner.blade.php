<div class="hero-container">
    <div class="slideshow">
        <div class="slide">
            <img src="{{ asset('/') }}public/newSlider.avif"
                 alt=""/>
        </div>
        <div class="slide">
            <img src="{{ asset('/') }}public/front/assets/img/slider/slider_02.jpg"
                 alt=""/>
        </div>
        <div class="slide">
            <img src="{{ asset('/') }}public/front/assets/img/slider/slider_03.jpg"
                 alt=""/>
        </div>
    </div>
</div>
