<!-- <div class="banner_image">
    <img src="{{ asset('/') }}public/front/assets/img/slider/slider_01.jpg" alt="">
</div> -->
<div class="faq_header_box">
    <div class="container">
        <h1>FD-1 Form</h1>
        <h4>Apply Registration Form</h4>
    </div>
</div>
