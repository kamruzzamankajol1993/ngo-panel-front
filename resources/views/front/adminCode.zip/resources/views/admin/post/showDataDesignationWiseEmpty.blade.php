<form>
    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>কর্মকর্তা</th>
        </tr>


        <tr>
            <td>

            </td>
            <td>
                <b>টেবিলে কোন তথ্য উপলব্ধ নেই</b>
            </td>
        </tr>






    </table>


    <button type="submit" class="btn btn-success mt-5">জমা দিন</button>

    </form>
