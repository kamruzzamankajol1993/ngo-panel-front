<?php
return [


	'wardlist'=>'Ward List',
	'addnewward'=>'Add New Ward',
	'caname'=>'Counsilor & Admin Name',
    'cityName'=>'City Corporation Name',
    'address'=>'Address',
    'newward'=>'New Ward Registration Form',
    'wardinfoenglish'=>'Ward Information(English)',
    'wardinfobangla'=>'Ward Information(Bangla)',
    'payinformation'=>'Payment information',
    'monthlyprice'=>'Monthly Price',
    'bcash'=>'Bkash',
    'nogod'=>'Nogod',
    'subtype'=>'Subscription Type',
    'PaymentMethod'=>'Payment Method',
    'Handcash'=>'Hand Cash',
    'paymentgateway'=>'Payment Gateway',
    'ward'=>'Ward',
    'ContactInformation'=>'Contact Information',
    'Email'=>'Email',
    'Phone'=>'Phone',
    'office'=>'Office',
    'District'=>'District',
    'postoffice'=>'Post Office',
    'postcode'=>'Post Code',
    'bimageLa'=>'Border Image(Landscape)',
    'bimageLo'=>'Border Image(Long)',
    'Logo'=>'Logo',
    'pollice'=>'Police Station',
    'annual'=>'By Annualy',
    'quater'=>'Quterly',
    'month'=>'Monthly',
   'wardcounsilinfo'=>'Ward Counsil Information',
   'upd'=>'Update Ward Registration Form',
   'uw'=>'Update Ward',
   'phis'=>'Payment History ',
   'renew'=>'Renew',
   'month'=>'Month',
   'payble'=>'Payable Amount',
   'paymentamount'=>'Payment Amount',
   'due'=>'Due',

   'wardadminlist'=>'Ward Admin List',
   'wardcounsilorlist'=>'Ward Counsilor List', 
   'addnewwardadmin'=>'Add New Ward Admin',
   'addnewwardcounsilor'=>'Add New Ward Counsilor',
   'confirmpassword'=>'Confirm Password',
   'assignrolls'=>'Assign Roles',
   'profileimage'=>'Profile Image',
   'wardadmininformation'=>'Ward Admin Information',
   'wardcounsilorinformation'=>'Ward Counsilor Information',
   'wardadmin'=>'Ward Admin',
   'wardcounsilor'=>'Ward Counsilor',
   'WardInformation'=>'Ward Information',
   'role'=>'Role',

  
    'UpdateWardAdmin'=>'Update Ward Admin',
   'updatewardCounsilor'=>'Update Ward Cousilor',
   'userbangla'=>'Name (Bangla)',



];

?>
