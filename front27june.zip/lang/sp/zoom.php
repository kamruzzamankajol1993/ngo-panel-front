<?php
return [

    'digitalSignature'=>'Digital Signature',
    'digitalSeal'=>'Digital Seal',
    'upload'=>'Upload'

];

?>
