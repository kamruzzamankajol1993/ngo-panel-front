<?php
return [
    'fdFourOneForm'=>'FD-4(1) Form',
    'addNew'=>'Add New Details'
];

?>
