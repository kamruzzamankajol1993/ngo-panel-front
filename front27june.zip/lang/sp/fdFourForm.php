<?php
return [
    'fdFourForm'=>'FD-4 Form',
    'addNew'=>'Add New Details'
];

?>
