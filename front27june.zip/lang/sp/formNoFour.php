<?php
return [
    'formNoFour'=>'Form No-4 (Monthly report)',
    'addNew'=>'Add New Details'
];

?>
