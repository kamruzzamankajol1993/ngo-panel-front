<?php
return [
    'formNoFive'=>'Form No-5 (Annual report)',
    'addNew'=>'Add New Details'
];

?>
