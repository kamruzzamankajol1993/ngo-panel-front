<?php
return [

    'fdFourOneForm'=>'এফডি - ৪(১) ফরম',
    'addNew'=>'নুতন বিবরণী যুক্ত করুন'
];

?>
