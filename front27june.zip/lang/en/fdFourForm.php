<?php
return [

    'fdFourForm'=>'এফডি - ৪ ফরম',
    'addNew'=>'নুতন বিবরণী যুক্ত করুন'
];

?>
