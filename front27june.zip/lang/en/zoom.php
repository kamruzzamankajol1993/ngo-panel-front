<?php
return [

    'digitalSignature'=>'ডিজিটাল স্বাক্ষর',
    'digitalSeal'=>'ডিজিটাল সিল',
    'upload'=>'আপলোড করুন'

];

?>
