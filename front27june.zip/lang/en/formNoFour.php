<?php
return [

    'formNoFour'=>'ফরম নং-৪',
    'addNew'=>'নুতন বিবরণী যুক্ত করুন'
];

?>
