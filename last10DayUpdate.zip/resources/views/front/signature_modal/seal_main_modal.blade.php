<div class="bs-example">
    <div id="myModalss" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <label for="" class="form-label">{{ trans('zoom.digitalSeal')}}: <span class="text-danger">*</span>
                        <span class="text-danger"><b style="font-size: 12px;">(Dimension:(300*100) , Size:Max 80 KB & Image Format:PNG)</b> </label></span>
                        <button type="button" data-toggle="tooltip" data-placement="top" title="Close" class="btn btn-danger btnss btn-sm"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>
                <div class="modal-body"  id="mResultss">

                </div>
                
            </div>
        </div>
    </div>
</div>
