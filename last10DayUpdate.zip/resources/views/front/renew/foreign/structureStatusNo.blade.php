
<div class="mb-3">
    <label class="form-label" for="">
 সংস্থার গঠনতন্ত্র পরিবর্তন না হয়ে থাকলে 'পরিবর্তন হয়নি' মর্মে  প্রত্যয়ন কপি (সংশ্লিষ্ট দেশের পিস অব জাস্টিস কতৃক নোটারীকৃত /সত্যায়িত ) : <span class="text-danger">*</span>
 <br><span class="text-danger" style="font-size: 12px;">(Maximum 500 KB)</span> </label></label>
    <input class="form-control" name="copy_of_chalan" data-parsley-required accept=".pdf" type="file" id="">
</div>
